
<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
        <i class="material-icons">admin_panel_settings</i>
    </div>
    <div class="card-content">
        <h4 class="card-title">Import Admin</h4>
        <div class="table-responsive">
    
            <form action="" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="file" name="file">
                </div>
                <div class="btn-box">
                    <button type="submit" class="btn btn-primary">import file</button>
                </div>
            </form>
            
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\resources\views/admin/insert-excel.blade.php ENDPATH**/ ?>