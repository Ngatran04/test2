
<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
	<div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
             <i class="material-icons">hotel_class</i>
         </div>
             <div class="card-content">
                 <h4 class="card-title">Danh sách khóa học</h4>
                  <div class="table-responsive">
                    <a href="<?php echo e(route('course.create')); ?>" class="btn btn-primary btn-round">Thêm khóa học</a><br>
                    <form action="">
                        <div class="col-md-3">
                            <input type="text" value="<?php echo e($search); ?>" name="search" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-blue btn-round btn-just-icon">
                            <i class="material-icons">search</i>
                            <div class="ripple-container"></div>
                        </button>
                    </form>              	
	
	<table class="table">
		<tr class="success">
                        <th>Mã</th>
                        <th>Tên khóa</th>
                        <th>Sửa</th>
                        <!-- <th>Xóa</th> -->
                    </tr>
                    <?php foreach ($listCourse as $course) : ?>
                    <tr>
                        <td><?php echo e($course->idCourse); ?></td>
                        <td><?php echo e($course->nameCourse); ?></td>


                            
                            <td><a class="btn btn-sm btn-warning"
                                    href="<?php echo e(route('course.edit', $course->idCourse)); ?>">Sửa</a></td>
                            <!-- <td>
                                <form action="<?php echo e(route('course.destroy', $course->idCourse)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger"onclick="return confirm('Bạn có chắc chắn muốn xóa ngành học? Thao tác này không thể hoàn tác.')">Xóa</button>
                            </td> -->
                        </tr>
        <?php endforeach ?>
                </table>
                <?php echo e($listCourse->appends([
        'search' => $search,
    ])->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\resources\views/course/index.blade.php ENDPATH**/ ?>