<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if(Session::exists('id')  ): ?>
                        <div class="form-group label-floating">
                            <label class="control-label">Họ Tên</label>
                            <h1 class="form-control" ><?php echo e(Session::get('idAdmin')); ?></h1>
                        </div>
                    
                 <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\test2\resources\views/admin/profile.blade.php ENDPATH**/ ?>