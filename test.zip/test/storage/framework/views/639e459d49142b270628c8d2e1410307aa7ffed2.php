
<?php $__env->startSection('content'); ?><br><br><br>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
        <i class="material-icons">import_contacts</i>
    </div>
    <div class="card-content">
        <h4 class="card-title">Tạo phiếu thu</h4>

        <form action="<?php echo e(route('bill.store')); ?>" method="post" class="form-horizontal">
          <div class="row">
              <?php echo csrf_field(); ?>

              <label class="col-md-3 label-on-left">Ngày nhập phiếu:</label>
              <div class="col-md-9">
                <div class="form-group label-floating is-empty">
                   <label class="control-label"></label>
                   <input type="date" class="form-control" name="billDate">
               </div>
           </div>


           <label class="col-md-3 label-on-left">Tên Sách:</label>          
           <div class="col-md-3">
             <select class="selectpicker" data-style="btn btn-primary btn-round" title="Tên sách" name="nameBook">
                <?php $__currentLoopData = $listBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($book->idBook); ?>"><?php echo e($book->nameBook); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

           <label class="col-md-3 label-on-left">Tên Sinh viên:</label>            
           <div class="col-md-9">
             <select class="selectpicker" data-style="btn btn-primary btn-round" title="Tên SV" name="name">
                <?php $__currentLoopData = $listStudent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($student->idStudent); ?>"><?php echo e($student->firstName); ?> <?php echo e($student->middleName); ?> <?php echo e($student->lastName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <label class="col-md-2 label-on-left">Số lượng:</label>
        <div class="col-md-4">
            <div class="form-group label-floating is-empty">
               <label class="control-label"></label>
               <input type="number" class="form-control" name="amountBook" min="1">
           </div>
       </div>
       
       <div class="row">
        <label class="col-md-3"></label>
        <div class="col-md-9" >
            <div class="form-group form-button">
                <button type="submit" class="btn btn-fill btn-rose">Thêm phiếu thu</button>
            </div>
        </div>
    </div>
    
</div>		
</form>
</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/bill/create.blade.php ENDPATH**/ ?>