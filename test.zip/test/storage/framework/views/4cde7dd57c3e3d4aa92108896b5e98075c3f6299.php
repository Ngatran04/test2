<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
	<div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
             <i class="material-icons">import_contacts</i>
         </div>
             <div class="card-content">
                 <h4 class="card-title">Inventory delivery voucher</h4>
                  <div class="table-responsive">

                    <form action="">
                        <div class="col-md-3">
                            <input type="text" value="<?php echo e($search); ?>" name="search" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-blue btn-round btn-just-icon">
                            <i class="material-icons">search</i>
                            <div class="ripple-container"></div>
                        </button>
                    </form>              	
	
	<table class="table table-hover">
		<tr class="success">
			<th>ID</th>
            <th>Date Time</th>
			<th>Name Book</th>
            <th>Name Student</th>
			<th>Quantity</th>
            <th width="10%"></th>
            <th width="10%"></th>
		</tr>
		<?php $__currentLoopData = $listBill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($bill->idBill); ?></td>
                <td><?php echo e($bill->billDate); ?></td>
				<td><?php echo e($bill->nameBook); ?></td>
                <td><?php echo e($bill->firstName); ?> <?php echo e($bill->middleName); ?> <?php echo e($bill->lastName); ?></td>
				<td><?php echo e($bill->amountBook); ?></td>
				<td><a class="btn btn-sm btn-fill btn-warning" href="<?php echo e(route('bill.edit', $bill->idBill)); ?>">EDIT</a></td>
                <td>
                    <form action="<?php echo e(route('bill.destroy', $bill->idBill)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa bill? Thao tác này không thể hoàn tác.')">DELETE</button>
                    </form>
                </td>
            </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<?php echo e($listBill->appends([
		'search' => $search
		])->links('pagination::bootstrap-4')); ?>

					</div>
                    <a href="<?php echo e(route('bill.export-excel')); ?>" class="btn btn-success btn-round">Export excel</a><br>

				</div>
		</div>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\test\resources\views/bill/index.blade.php ENDPATH**/ ?>