
<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
       <i class="material-icons">import_contacts</i>
   </div>
   <div class="card-content">
       <h4 class="card-title">LIST STUDENTS AND BOOK REGISTER</h4>
       <div class="table-responsive">
        <a href="<?php echo e(route('register.create')); ?>" class="btn btn-primary btn-round">ADD STUDENT AND BOOK</a><br>

        <form action="">
            <div class="col-md-3">
                <input type="text" value="<?php echo e($search); ?>" name="search" class="form-control">
            </div>
            <button type="submit" class="btn btn-blue btn-round btn-just-icon">
                <i class="material-icons">search</i>
                <div class="ripple-container"></div>
            </button>
        </form>              	
        
        <table class="table table-hover">
          <tr class="success">
              <th width="5%">ID</th>
             <th>Name Student</th>
             <th>Name Book</th>
             <th width="10%">Handing Out Books</th>
         </tr>
         <?php $__currentLoopData = $listRegister; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?= $register->idRegister ?></td>
            <td><?php echo e($register->firstName); ?> <?php echo e($register->middleName); ?> <?php echo e($register->lastName); ?></td>
            <td><div class="col-md-7">
                <?php echo e($register->nameBook); ?></div>
        </td>
            <td><a class="btn btn-sm btn-fill btn-success" href="<?php echo e(route('bill.show', $register->idRegister)); ?>"><i class="material-icons">skip_next</i></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($listRegister->appends([
    'search' => $search
    ])->links('pagination::bootstrap-4')); ?>

</div>
<a href="<?php echo e(route('register.export-excel')); ?>" class="btn btn-success btn-round">Export excel</a><br>
     
</div>
</div>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\test\resources\views/register/index.blade.php ENDPATH**/ ?>