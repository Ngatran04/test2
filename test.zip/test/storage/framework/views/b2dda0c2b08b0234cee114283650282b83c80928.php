<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
        <i class="material-icons">class</i>
    </div>
        <div class="card-content">
            <h4 class="card-title">EDIT GRADE</h4>

	<form action="<?php echo e(route('grade.update', $grade->idGrade)); ?>" method="post" class="form-horizontal">
		<div class="row">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>

		<label class="col-md-3 label-on-left">Name Grade:</label>
		<div class="col-md-9">
            <div class="form-group label-floating is-empty">
                 <label class="control-label"></label>
                 <input type="text" class="form-control" name="name" value="<?php echo e($grade->nameGrade); ?>" required>
            </div>
        </div>

        <label class="col-md-3 label-on-left">Name Course:</label>            
           <div class="col-md-3">
             <select class="selectpicker" data-style="btn btn-primary btn-round" title="Chọn tên khóa học" name="nameCourse" required>
                <?php $__currentLoopData = $listCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($course->idCourse); ?>"
                 <?php 
                 if($grade->idCourse == $course->idCourse){
                   echo "selected";
               }
               ?>
               ><?php echo e($course->nameCourse); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
        <div class="row">
            <label class="col-md-3"></label>
                <div class="col-md-9" >
                    <div class="form-group form-button">
                        <button type="submit" class="btn btn-fill btn-rose">Update</button>
                    </div>
                </div>
        </div>
		</div>	
	</form>
			</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\test\resources\views/grade/edit.blade.php ENDPATH**/ ?>