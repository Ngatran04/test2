<footer class="footer">
    <div class="container-fluid">
        
        <p class="copyright pull-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            N - N 's BKACAD student management website
        </p>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/layout/footer.blade.php ENDPATH**/ ?>