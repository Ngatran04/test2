
<?php $__env->startSection('content'); ?><br><br><br>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
        <i class="material-icons">admin_panel_settings</i>
    </div>
    <div class="card-content">
     <h4 class="card-title">Thông tin cá nhân</h4>
     <div class="row">
         <div class="col-md-10">
             <div class="form-group label-floating">
                 <label class="control-label">HỌ TÊN</label>
                 <h1 class="form-control" ><?php echo e(Session::get('name')); ?><?php echo e(Session::get('name1')); ?> </h1>
             </div>
            </div>
         <div class="col-md-5">
            <div class="form-group label-floating">
                <label class="control-label">USERNAME</label>
                <h1 class="form-control" ><?php echo e(Session::get('username')); ?><?php echo e(Session::get('username1')); ?> </h1>
            </div>
        </div>
        <div class="col-md-5">
            <div class="form-group label-floating">
                <label class="control-label">PASSWORD</label>
                <h1 class="form-control" ><?php echo e(Session::get('password')); ?><?php echo e(Session::get('password1')); ?> </h1>
            </div>
        </div>
        <div class="col-md-7">
            <div class="form-group label-floating">
                <label class="control-label">EMAIL</label>
                <h1 class="form-control" ><?php echo e(Session::get('email')); ?><?php echo e(Session::get('email1')); ?> </h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="form-group label-floating">
                <label class="control-label">SỐ ĐIỆN THOẠI</label>
                <h1 class="form-control" >
                <?php echo e(Session::get('phone')); ?>  <?php echo e(Session::get('phone1')); ?></h1>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group label-floating">
                <label class="control-label">NGÀY SINH</label>
                <h1 class="form-control" >
                   <?php echo e(Session::get('dateBirth')); ?><?php echo e(Session::get('dateBirth1')); ?>

               </h1>
           </div>
       </div>
   </div>   
   <div class="col-md-3">
     <div class="form-group label-floating">
         <label class="control-label">GIỚI TÍNH</label>
         <h1 class="form-control">
            <?php if(Session::get('gender')  == '1' || Session::get('gender1')  == '1'): ?>
            Nam
            <?php else: ?>
            Nữ
            <?php endif; ?>
        </h1>
    </div>
</div>

<div class="row">
 <div class="col-md-4">
     <div class="form-group label-floating">
         <label class="control-label">CHỨC VỤ</label>
         <h1 class="form-control">
             
             <?php if(Session::get('role')): ?>
             Super Admin
             <?php else: ?>
             Admin
             <?php endif; ?>
         </h1>
     </div>
 </div>
</div>

</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/admin/detail.blade.php ENDPATH**/ ?>