<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
	<div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
             <i class="material-icons">subject</i>
         </div>
             <div class="card-content">
                 <h4 class="card-title">DANH SÁCH MÔN HỌC</h4>
                  <div class="table-responsive">
                    <a href="<?php echo e(route('subject.create')); ?>" class="btn btn-primary btn-round">add subject</a><br>
                    <form action="">
                        <div class="col-md-3">
                            <input type="text" value="<?php echo e($search); ?>" name="search" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-blue btn-round btn-just-icon">
                            <i class="material-icons">search</i>
                            <div class="ripple-container"></div>
                        </button>
                    </form>              	
	
	<table class="table table-hover">
		<tr class="success">
                        <th width="5%">ID</th>
                        <th>Name Subject</th>
                        <th>Grade</th>
                        <th width="10%"></th>
                        <!-- <th>Xóa</th> -->
                    </tr>
                    <?php $__currentLoopData = $listSubject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($subject->idSubject); ?></td>
                        <td><?php echo e($subject->nameSubject); ?></td>
                        <td><?php echo e($subject->nameGrade); ?></td>



                            
                            <td><a class="btn btn-sm btn-warning"
                                    href="<?php echo e(route('subject.edit', $subject->idSubject)); ?>">EDIT</a></td>
                            <!-- <td>
                                <form action="<?php echo e(route('subject.destroy', $subject->idSubject)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger"onclick="return confirm('Bạn có chắc chắn muốn xóa môn học? Thao tác này không thể hoàn tác.')">Xóa</button>
                            </td>
                            </td> -->
                        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </table>
                <?php echo e($listSubject->appends([
        'search' => $search,
    ])->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/subject/index.blade.php ENDPATH**/ ?>