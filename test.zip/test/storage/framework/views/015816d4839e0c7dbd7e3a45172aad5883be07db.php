<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
        <i class="material-icons">school</i>
    </div>
        <div class="card-content">
            <h4 class="card-title">Cập Nhật Sinh viên</h4>

	<form action="<?php echo e(route('student.update', $student->idStudent)); ?>" method="post" class="form-horizontal">
		<div class="row">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>

		<label class="col-md-3 label-on-left">FirstName:</label>
		<div class="col-md-9">
            <div class="form-group label-floating is-empty">
                 <label class="control-label"></label>
                 <input type="text" class="form-control" name="firstName" value=" <?php echo e($student -> firstName); ?>">
            </div>
        </div>

        <label class="col-md-3 label-on-left">MiddleName:</label>
		<div class="col-md-9">
            <div class="form-group label-floating is-empty">
                 <label class="control-label"></label>
                 <input type="text" class="form-control" name="middleName" value=" <?php echo e($student -> middleName); ?>">
            </div>
        </div>

        <label class="col-md-3 label-on-left">LastName:</label>
		<div class="col-md-9">
            <div class="form-group label-floating is-empty">
                 <label class="control-label"></label>
                 <input type="text" class="form-control" name="name" value=" <?php echo e($student -> lastName); ?>">
            </div>
        </div>

        <label class="col-md-3 label-on-left">Email:</label>
		<div class="col-md-9">
            <div class="form-group label-floating is-empty">
                 <label class="control-label"></label>
                 <input type="text" class="form-control" name="email" value=" <?php echo e($student -> email); ?>">
            </div>
        </div>

        <label class="col-md-3 label-on-left">Số điện thoại:</label>
		<div class="col-md-9">
            <div class="form-group label-floating is-empty">
                 <label class="control-label"></label>
                 <input type="number" class="form-control" name="phone" value=" <?php echo e($student->phone); ?>" required>
            </div>
        </div>


        
        <label class="col-md-3 label-on-left">Giới tính:</label>            
        <div class="col-md-2">
            <select class="selectpicker" data-style="btn btn-primary btn-round" title="Chọn Giới tính" name="gender" value=" <?php echo e($student -> gender); ?>"required>
            <option value="1">Nam</option>
            <option value="0">Nữ</option>
            </select>
        </div>   
        <label class="col-md-3 label-on-left">Ngày sinh:</label>
		<div class="col-md-3">
            <div class="form-group label-floating is-empty">
                 <label class="control-label"></label>
                 <input type="date" class="form-control datepicker" name="birthDate" value=" <?php echo e($student->birthDate); ?>" />
            </div>
        </div>

        <!-- <label class="col-md-3 label-on-left">Tình trạng:</label>            
        <div class="col-md-2">
            <select class="selectpicker" data-style="btn btn-primary btn-round" title="Chọn tình trạng" name="status" required value=" <?php echo e($student -> status); ?>">
            <option value="1">Đã đăng ký</option>
            <option value="0">Chưa đăng ký</option>

            </select>
        </div>    -->

        

		<label class="col-md-3 label-on-left">Tên lớp:</label>            
           <div class="col-md-3">
             <select class="selectpicker" data-style="btn btn-primary btn-round" title="Chọn tên lớp" name="nameGrade">
                <?php $__currentLoopData = $listGrade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($grade->idGrade); ?>"
                 <?php 
                 if($student->idGrade == $grade->idGrade){
                   echo "selected";
               }
               ?>
               ><?php echo e($grade->nameGrade); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>

       
       
		
		<div class="row">
            <label class="col-md-3"></label>
                <div class="col-md-9" >
                    <div class="form-group form-button">
                        <button type="submit" class="btn btn-fill btn-rose">Cập nhật</button>
                    </div>
                </div>
        </div>
		
		</div>		
	</form>
			</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/student/edit.blade.php ENDPATH**/ ?>