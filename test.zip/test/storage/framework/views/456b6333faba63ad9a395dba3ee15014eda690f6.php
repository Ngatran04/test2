<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
	<div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
             <i class="material-icons">class</i>
         </div>
             <div class="card-content">
                 <h4 class="card-title">DANH SÁCH LỚP</h4>
                  <div class="table-responsive">
                    <a href="<?php echo e(route('grade.create')); ?>" class="btn btn-primary btn-round">add grade</a><br>
                    <form action="">
                        <div class="col-md-3">
                            <input type="text" value="<?php echo e($search); ?>" name="search" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-blue btn-round btn-just-icon">
                            <i class="material-icons">search</i>
                            <div class="ripple-container"></div>
                        </button>
                    </form>              	
	
	<table class="table table-hover">
		<tr class="success">
                        <th>ID</th>
                        <th>Name Grade</th>
                        <th>Name Course</th>
                        <th>Number of Books Distributed </th>
                        <th width="10%"></th>
                    </tr>
                    <?php $__currentLoopData = $listGrade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($grade->idGrade); ?></td>
                            <td><?php echo e($grade->nameGrade); ?></td>
                            <td><?php echo e($grade->nameCourse); ?></td>
                            <td>
                                <?php
                $sum =\App\Models\bill::where('idStudent','=',$grade->idGrade)
                ->sum('bill.amountBook');                
            ?>
            <?php echo e($grade->amount + $sum); ?>

                            </td>
                            
                            <td><a class="btn btn-sm btn-warning"
                                    href="<?php echo e(route('grade.edit', $grade->idGrade)); ?>">EDIT</a></td>
                            <!-- <td>
                                <form action="<?php echo e(route('grade.destroy', $grade->idGrade)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger"onclick="return confirm('Bạn có chắc chắn muốn xóa lớp? Thao tác này không thể hoàn tác.')">Xóa</button>
                            </td> -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($listGrade->appends([
        'search' => $search,
    ])->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/grade/index.blade.php ENDPATH**/ ?>