
<?php $__env->startSection('title', 'Danh sách các ngành'); ?>
    <?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header card-header-icon" data-background-color="rose">
            <i class="material-icons">assignment</i>
        </div>
        <div class="card-content">
            <h4 class="card-title">Danh sách Admin</h4>
            <div class="table-responsive">
                <a href="<?php echo e(route('genre.create')); ?>">Thêm ngành</a>
                <form action="">
                    <input type="text" value="<?php echo e($search); ?>" name="search">
                    <button>Search</button>
                </form>
                <table class="table">
                    <tr>
                        <th>Mã</th>
                        <th>Tên</th>
                        <th>username</th>
                        <th>password</th>
                        <th>email</th>
                        <th>SDT</th>
                        <th>giới tính</th>
                        <th>Quyền</th>  
                    </tr>
                    <?php foreach ($listAdmin as $admin) : ?>
                    <tr>
                        <td><?php echo e($admin->idAdmin); ?></td>
                        <td><?php echo e($admin->nameAdmin); ?></td>


                            
                            <td><a class="btn btn-sm btn-warning"
                                    href="<?php echo e(route('admin.edit', $admin->idAdmin)); ?>">Sửa</a></td>
                            <td>
                                <form action="<?php echo e(route('admin.destroy', $admin->idAdmin)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Xóa</button>
                                </form>
                            </td>
                        </tr>
        <?php endforeach ?>
                </table>
                <?php echo e($listAdmin->appends([
        'search' => $search,
    ])->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\resources\views/admin/admin.blade.php ENDPATH**/ ?>