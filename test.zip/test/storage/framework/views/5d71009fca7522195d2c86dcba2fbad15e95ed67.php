<footer class="footer">
    <div class="container-fluid">  
        <p class="copyright pull-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            N - N 's BKACAD book management website
        </p>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\test\resources\views/layout/footer.blade.php ENDPATH**/ ?>