<?php $__env->startSection('content'); ?><br><br><br>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
        <i class="material-icons">subject</i>
    </div>
        <div class="card-content">
            <h4 class="card-title">ADD SUBJECT</h4>

	<form action="<?php echo e(route('subject.store')); ?>" method="post" class="form-horizontal">
		<div class="row">
		<?php echo csrf_field(); ?>

		<label class="col-md-3 label-on-left">Name Subject:</label>
		<div class="col-md-9">
            <div class="form-group label-floating is-empty">
                 <label class="control-label"></label>
                 <input type="text" class="form-control" name="name">
            </div>
        </div>

		
       
		<div class="row">
            <label class="col-md-3"></label>
            <div class="col-md-9" style="left: 400px">
                <div class="form-group form-button">
                    <button type="submit" class="btn btn-fill btn-rose">Add Subject</button>
                </div>
            </div>
        </div>
		
		</div>		
	</form>
			</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\test\resources\views/subject/create.blade.php ENDPATH**/ ?>