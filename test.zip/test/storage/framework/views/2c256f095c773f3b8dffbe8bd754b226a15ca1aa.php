
<?php $__env->startSection('content'); ?><br><br><br>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <strong>THÔNG BÁO : </strong><?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-header card-header-icon" data-background-color="rose">
        <i class="material-icons">admin_panel_settings</i>
    </div>
    <div class="card-content">
        <h4 class="card-title">Danh sách Admin</h4>
        <div class="table-responsive">
            <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary btn-round">Thêm admin</a><br>               
            <form action="">
                <div class="col-md-3">
                    <input type="text" value="<?php echo e($search); ?>" name="search" class="form-control">
                </div>
                <button type="submit" class="btn btn-blue btn-round btn-just-icon">
                    <i class="material-icons">search</i>
                    <div class="ripple-container"></div>
                </button>
            </form>
            
            <table class="table table-hover">
                <tr class="success">
                    <th>Tên</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Email</th>
                    <th>SĐT</th>
                    <th>Ngày Sinh</th>
                    <th>Giới Tính</th>
                    <th>Chức Vụ</th>  
                    <th></th>
                    <th></th>
                </tr>
                <?php foreach ($listAdmin as $admin) : ?>
                    <tr>                       
                        <td><?php echo e($admin->nameAdmin); ?></td>
                        <td><?php echo e($admin->username); ?></td>
                        <td><?php echo e($admin->password); ?></td>
                        <td><?php echo e($admin->email); ?></td>
                        <td><?php echo e($admin->phone); ?></td>
                        <td><?php echo e($admin->dateBirth); ?></td>
                        <td><?php echo e($admin->gender == 1 ? 'Nam' : 'Nữ'); ?></td>
                        <td><?php echo e($admin->role == 1 ? 'Super Admin' : 'Admin'); ?></td>
                        
                        <td><a class="btn btn-sm btn-warning"
                            href="<?php echo e(route('admin.edit', $admin->idAdmin)); ?>">Sửa</a>
                        </td>
                        <td>
                            <form action="<?php echo e(route('admin.destroy', $admin->idAdmin)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa Admin? Thao tác này không thể hoàn tác.')">Xóa</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </table>
                
                <?php echo e($listAdmin->appends([
                'search' => $search,
                ])->links('pagination::bootstrap-4')); ?>

            </div>
            <a href="<?php echo e(route('admin.import-excel')); ?>" class="btn btn-rose btn-round">Import excel</a>
            <a href="<?php echo e(route('admin.export-excel')); ?>" class="btn btn-success btn-round">Export excel</a><br>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\resources\views/admin/index.blade.php ENDPATH**/ ?>